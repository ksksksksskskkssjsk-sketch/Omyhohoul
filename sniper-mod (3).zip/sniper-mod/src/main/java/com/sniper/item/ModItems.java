package com.sniper.item;

import com.sniper.SniperConfig;
import com.sniper.SniperMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.function.Function;

public class ModItems {
    public static final Item SNIPER_RIFLE = register("sniper_rifle", SniperRifleItem::new,
            new Item.Settings().maxCount(1).maxDamage(SniperConfig.get().maxDurability)
                    .rarity(Rarity.RARE).repairable(Items.IRON_INGOT).enchantable(10));

    public static final Item SNIPER_AMMO = register("sniper_ammo",
            s -> new SniperAmmoItem(s, AmmoType.STANDARD), new Item.Settings());
    public static final Item SNIPER_AMMO_PIERCING = register("sniper_ammo_piercing",
            s -> new SniperAmmoItem(s, AmmoType.PIERCING), new Item.Settings().rarity(Rarity.UNCOMMON));
    public static final Item SNIPER_AMMO_EXPLOSIVE = register("sniper_ammo_explosive",
            s -> new SniperAmmoItem(s, AmmoType.EXPLOSIVE), new Item.Settings().rarity(Rarity.UNCOMMON));
    public static final Item SNIPER_AMMO_INCENDIARY = register("sniper_ammo_incendiary",
            s -> new SniperAmmoItem(s, AmmoType.INCENDIARY), new Item.Settings().rarity(Rarity.UNCOMMON));

    private static <T extends Item> T register(String name, Function<Item.Settings, T> factory, Item.Settings settings) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(SniperMod.MOD_ID, name));
        return Registry.register(Registries.ITEM, key, factory.apply(settings.registryKey(key)));
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(SNIPER_RIFLE);
            entries.add(SNIPER_AMMO);
            entries.add(SNIPER_AMMO_PIERCING);
            entries.add(SNIPER_AMMO_EXPLOSIVE);
            entries.add(SNIPER_AMMO_INCENDIARY);
        });
    }
}
