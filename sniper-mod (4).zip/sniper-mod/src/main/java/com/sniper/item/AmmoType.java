package com.sniper.item;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

public enum AmmoType {
    //         dmg    speed pierce recoil boom  fire trail                         colour from, to (RGB)
    STANDARD  (1.00f, 1.0, 1, 1.00f, 0.0f, 0, ParticleTypes.END_ROD,        0xB8F0FF, 0x3C8CFF),
    PIERCING  (0.85f, 1.2, 3, 1.10f, 0.0f, 0, ParticleTypes.ELECTRIC_SPARK, 0xC080FF, 0x4A2A9A),
    EXPLOSIVE (0.50f, 0.8, 1, 1.40f, 2.5f, 0, ParticleTypes.SMOKE,          0xFF6A3C, 0x501410),
    INCENDIARY(0.80f, 0.9, 1, 1.00f, 0.0f, 6, ParticleTypes.FLAME,          0xFFC040, 0xC01800);

    public final float damageMult;
    public final double speedMult;     // lower speed = more bullet drop
    public final int pierce;           // entities hit before the bullet stops
    public final float recoilMult;
    public final float explosionPower; // 0 = none (never breaks blocks)
    public final int fireSeconds;
    public final ParticleEffect trail;
    public final int colorFrom;
    public final int colorTo;

    AmmoType(float damageMult, double speedMult, int pierce, float recoilMult,
             float explosionPower, int fireSeconds, ParticleEffect trail, int colorFrom, int colorTo) {
        this.damageMult = damageMult;
        this.speedMult = speedMult;
        this.pierce = pierce;
        this.recoilMult = recoilMult;
        this.explosionPower = explosionPower;
        this.fireSeconds = fireSeconds;
        this.trail = trail;
        this.colorFrom = colorFrom;
        this.colorTo = colorTo;
    }
}
