package com.sniper.net;

import com.sniper.SniperMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> shooter. kind: 0 = body hit, 1 = headshot, 2 = kill. */
public record HitMarkerPayload(int kind) implements CustomPayload {
    public static final CustomPayload.Id<HitMarkerPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SniperMod.MOD_ID, "hit_marker"));
    public static final PacketCodec<RegistryByteBuf, HitMarkerPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, HitMarkerPayload::kind,
            HitMarkerPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
