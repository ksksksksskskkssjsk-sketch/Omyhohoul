package com.sniper;

import com.sniper.item.ModItems;
import com.sniper.net.HitMarkerPayload;
import com.sniper.net.RecoilPayload;
import com.sniper.net.TracerPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public class SniperMod implements ModInitializer {
    public static final String MOD_ID = "sniper";

    @Override
    public void onInitialize() {
        ModItems.register();
        Delayed.init();
        PayloadTypeRegistry.playS2C().register(RecoilPayload.ID, RecoilPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TracerPayload.ID, TracerPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HitMarkerPayload.ID, HitMarkerPayload.CODEC);
    }
}
