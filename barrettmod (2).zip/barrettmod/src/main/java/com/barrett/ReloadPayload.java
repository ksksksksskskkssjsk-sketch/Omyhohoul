package com.barrett;

import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ReloadPayload() implements CustomPayload {
	public static final Id<ReloadPayload> ID = new Id<>(Identifier.of(BarrettMod.ID, "reload"));
	public static final PacketCodec<net.minecraft.network.PacketByteBuf, ReloadPayload> CODEC = PacketCodec.unit(new ReloadPayload());
	@Override public Id<? extends CustomPayload> getId() { return ID; }
}
