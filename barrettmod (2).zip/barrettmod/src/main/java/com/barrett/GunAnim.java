package com.barrett;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** First-person gun animation. All numbers below are meant to be tweaked. */
public final class GunAnim {
	public static boolean inspecting;

	// ---- TUNE ME (camera space: +X right, +Y up, -Z forward; blocks / degrees) ----
	private static final float PX = 0.35f, PY = -0.35f, PZ = -0.75f; // rotation pivot

	// {x, y, z, rotX, rotY, rotZ}
	private static final float[] ADS = {-0.36f, 0.13f, 0.10f,   0f,  0f,   0f}; // RMB aim: slide to center
	private static final float[] INS = {-0.10f, 0.12f, 0.05f, -38f, 28f, -20f}; // V inspect: muzzle up, rolled
	private static final float[] SPR = { 0.02f,-0.12f, 0.05f,  22f, 18f, -14f}; // sprint: dropped, muzzle down-left
	private static final float[] REC = { 0.00f, 0.015f,0.12f,  -4f,  0f,   0f}; // recoil kick on click

	private static final float[] REL = { 0.04f,-0.22f, 0.08f,  34f,-12f,  26f}; // R reload: tilt down

	private static final float SPEED = 12f; // pose blend speed
	// ---------------------------------------------------------------------------------

	private static float ads, ins, spr, rec, relT, walk, swayX, swayY, phase, time;
	private static float lastYaw, lastPitch;
	private static boolean init;
	private static long last = System.nanoTime();

	private static float sm(float x) { return x * x * (3f - 2f * x); }

	public static void fire() { rec = 1f; inspecting = false; }
	public static void reload() { relT = 1f; inspecting = false; }
	public static float adsAmount() { return sm(ads); }

	public static void apply(AbstractClientPlayerEntity player, MatrixStack m) {
		MinecraftClient mc = MinecraftClient.getInstance();
		long now = System.nanoTime();
		float dt = MathHelper.clamp((now - last) / 1.0e9f, 0.0001f, 0.05f);
		last = now;
		time += dt;

		boolean free = mc.currentScreen == null;
		boolean sprinting = player.isSprinting();
		boolean wantAds = free && !sprinting && relT <= 0f && mc.options.useKey.isPressed();
		if (wantAds || sprinting) inspecting = false;

		float k = 1f - (float) Math.exp(-dt * SPEED);
		ads += ((wantAds ? 1f : 0f) - ads) * k;
		ins += ((inspecting ? 1f : 0f) - ins) * (1f - (float) Math.exp(-dt * 7f));
		spr += ((sprinting ? 1f : 0f) - spr) * k;
		rec = Math.max(0f, rec - dt * 7f);
		relT = Math.max(0f, relT - dt / 2.4f);
		float rl = relT > 0f ? (float) Math.sin(Math.PI * (1f - relT)) : 0f;

		// mouse sway (lags behind look direction)
		float yaw = player.getYaw(), pitch = player.getPitch();
		if (!init) { lastYaw = yaw; lastPitch = pitch; init = true; }
		float vy = MathHelper.wrapDegrees(yaw - lastYaw) / dt;
		float vp = (pitch - lastPitch) / dt;
		lastYaw = yaw; lastPitch = pitch;
		float sk = 1f - (float) Math.exp(-dt * 9f);
		swayX += (MathHelper.clamp(vy * 0.012f, -4f, 4f) - swayX) * sk;
		swayY += (MathHelper.clamp(vp * 0.012f, -4f, 4f) - swayY) * sk;

		// walk bob
		Vec3d v = player.getVelocity();
		float speed = (float) Math.sqrt(v.x * v.x + v.z * v.z);
		float walkT = player.isOnGround() ? MathHelper.clamp(speed / 0.12f, 0f, 1.5f) : 0f;
		walk += (walkT - walk) * k;
		phase += dt * (sprinting ? 12f : 9f);

		float a = sm(ads), i = sm(ins), s = sm(spr), r = rec * rec, l = sm(rl);
		float bobMul = (1f - 0.85f * a) * (1f - 0.7f * i);

		float px = ADS[0]*a + INS[0]*i + SPR[0]*s + REC[0]*r + REL[0]*l + (float) Math.sin(phase) * 0.012f * walk * bobMul;
		float py = ADS[1]*a + INS[1]*i + SPR[1]*s + REC[1]*r + REL[1]*l
				+ Math.abs((float) Math.cos(phase)) * 0.014f * walk * bobMul
				+ (float) Math.sin(time * 1.6f) * 0.003f * (1f - 0.8f * a);
		float pz = ADS[2]*a + INS[2]*i + SPR[2]*s + REC[2]*r + REL[2]*l;

		float swayMul = 1f - 0.75f * a;
		float rx = INS[3]*i + SPR[3]*s + REC[3]*r + REL[3]*l + swayY * swayMul + (float) Math.sin(time * 1.1f) * 2f * i;
		float ry = INS[4]*i + SPR[4]*s + REC[4]*r + REL[4]*l + swayX * swayMul;
		float rz = INS[5]*i + SPR[5]*s + REC[5]*r + REL[5]*l + (float) Math.sin(time * 1.4f) * 2.5f * i
				+ (float) Math.sin(phase) * 0.8f * walk * bobMul;

		m.translate(px, py, pz);
		m.translate(PX, PY, PZ);
		m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
		m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
		m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
		m.translate(-PX, -PY, -PZ);
	}
}
