package com.barrett;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class BarrettClient implements ClientModInitializer {
	public static KeyBinding INSPECT, RELOAD;

	@Override
	public void onInitializeClient() {
		KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(BarrettMod.ID, "main"));
		INSPECT = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.barrettmod.inspect", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, cat));
		RELOAD = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.barrettmod.reload", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, cat));

		// START tick: consume clicks before vanilla turns them into attack/mine
		ClientTickEvents.START_CLIENT_TICK.register(client -> {
			if (client.player == null) return;
			ItemStack s = client.player.getMainHandStack();
			boolean holding = s.isOf(BarrettMod.BARRETT);
			boolean free = client.currentScreen == null;

			if (!holding) {
				GunAnim.inspecting = false;
				while (INSPECT.wasPressed()) { }
				while (RELOAD.wasPressed()) { }
				return;
			}

			while (client.options.attackKey.wasPressed()) {
				if (!free) continue;
				boolean cd = client.player.getItemCooldownManager().isCoolingDown(s);
				if (cd) continue;
				ClientPlayNetworking.send(new ShootPayload(GunAnim.adsAmount() > 0.8f));
				if (s.getDamage() < s.getMaxDamage()) {
					GunAnim.fire();
					client.player.setPitch(client.player.getPitch() - 2.5f); // camera kick
				}
			}
			while (RELOAD.wasPressed()) {
				if (free && s.getDamage() > 0 && !client.player.getItemCooldownManager().isCoolingDown(s)) {
					ClientPlayNetworking.send(new ReloadPayload());
					GunAnim.reload();
				}
			}
			while (INSPECT.wasPressed()) GunAnim.inspecting = !GunAnim.inspecting;
		});
	}
}
