package com.barrett;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public class BarrettMod implements ModInitializer {
	public static final String ID = "barrettmod";
	public static final int MAG = 10;          // rounds per magazine
	public static final int FIRE_CD = 14;      // ticks between shots (bolt-ish)
	public static final int RELOAD_CD = 50;    // ticks to reload
	public static final double RANGE = 200;
	public static final float DAMAGE = 30f;    // 15 hearts

	public static Item BARRETT;

	private record Task(int tick, Runnable run) {}
	private static final List<Task> TASKS = new ArrayList<>();

	private static SoundEvent snd(String id) { return SoundEvent.of(Identifier.ofVanilla(id)); }

	@Override
	public void onInitialize() {
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "barrett_m82a1"));
		// durability bar = ammo (full bar = full mag)
		BARRETT = Registry.register(Registries.ITEM, key,
				new Item(new Item.Settings().registryKey(key).maxDamage(MAG)
						.component(DataComponentTypes.LORE, new LoreComponent(List.of(
								Text.literal(".50 BMG anti-materiel rifle").formatted(net.minecraft.util.Formatting.GRAY),
								Text.literal("LMB fire - RMB aim - R reload - V inspect").formatted(net.minecraft.util.Formatting.DARK_GRAY))))));

		// delayed actions (bolt cycle sound etc.)
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			int now = server.getTicks();
			TASKS.removeIf(task -> { if (now >= task.tick()) { task.run().run(); return true; } return false; });
		});
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(BARRETT));

		// holding the gun: left click never mines or melees
		AttackBlockCallback.EVENT.register((p, w, h, pos, dir) ->
				p.getMainHandStack().isOf(BARRETT) ? ActionResult.FAIL : ActionResult.PASS);
		AttackEntityCallback.EVENT.register((p, w, h, e, hit) ->
				p.getMainHandStack().isOf(BARRETT) ? ActionResult.FAIL : ActionResult.PASS);

		PayloadTypeRegistry.playC2S().register(ShootPayload.ID, ShootPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ReloadPayload.ID, ReloadPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(ShootPayload.ID, (pl, ctx) -> shoot(ctx.player(), pl.ads()));
		ServerPlayNetworking.registerGlobalReceiver(ReloadPayload.ID, (pl, ctx) -> reload(ctx.player()));
	}

	private static void shoot(ServerPlayerEntity p, boolean ads) {
		ItemStack s = p.getMainHandStack();
		if (!s.isOf(BARRETT) || p.isSpectator()) return;
		ServerWorld w = (ServerWorld) p.getEntityWorld();
		if (p.getItemCooldownManager().isCoolingDown(s)) return;

		if (s.getDamage() >= s.getMaxDamage()) { // empty
			w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("block.dispenser.fail"), SoundCategory.PLAYERS, 1f, 1.4f);
			p.getItemCooldownManager().set(s, 8);
			p.sendMessage(Text.literal("Empty - press R"), true);
			return;
		}

		s.setDamage(s.getDamage() + 1);
		p.getItemCooldownManager().set(s, FIRE_CD);
		p.sendMessage(Text.literal("Ammo " + (s.getMaxDamage() - s.getDamage()) + "/" + MAG), true);

		w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("entity.generic.explode"), SoundCategory.PLAYERS, 4f, 1.7f);
		w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("entity.firework_rocket.blast"), SoundCategory.PLAYERS, 3f, 0.6f);
		// bolt cycle after the shot
		TASKS.add(new Task(w.getServer().getTicks() + 8, () ->
				w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("block.piston.extend"), SoundCategory.PLAYERS, 0.5f, 1.8f)));

		Vec3d eye = p.getEyePos();
		// accuracy: tight when aiming, wide when hip-firing / sprinting / jumping / moving
		float spread = ads ? 0.1f : (p.isSneaking() ? 1.2f : 2.5f);
		if (p.isSprinting()) spread += 3f;
		if (!p.isOnGround()) spread += 3f;
		else if (p.getVelocity().horizontalLengthSquared() > 0.003) spread += 1.5f;
		float yaw = p.getYaw() + (p.getRandom().nextFloat() - 0.5f) * 2f * spread;
		float pit = p.getPitch() + (p.getRandom().nextFloat() - 0.5f) * 2f * spread;
		Vec3d dir = Vec3d.fromPolar(pit, yaw);

		// muzzle blast
		Vec3d muzzle = eye.add(dir.multiply(1.6)).add(0, -0.15, 0);
		w.spawnParticles(ParticleTypes.LARGE_SMOKE, muzzle.x, muzzle.y, muzzle.z, 3, 0.05, 0.05, 0.05, 0.01);
		w.spawnParticles(ParticleTypes.POOF, muzzle.x, muzzle.y, muzzle.z, 4, 0.1, 0.1, 0.1, 0.05);
		Vec3d end = eye.add(dir.multiply(RANGE));
		BlockHitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.NONE, p));
		if (bh.getType() != HitResult.Type.MISS) end = bh.getPos();

		double maxSq = eye.squaredDistanceTo(end);
		EntityHitResult eh = ProjectileUtil.raycast(p, eye, end, new Box(eye, end).expand(1.0),
				e -> !e.isSpectator() && e.canHit(), maxSq);
		if (eh != null) {
			Entity t = eh.getEntity();
			end = eh.getPos();
			float dmg = DAMAGE;
			boolean head = t instanceof LivingEntity le && end.y > le.getEyeY() - 0.25;
			if (head) dmg *= 1.5f; // headshot
			t.damage(w, p.getDamageSources().playerAttack(p), dmg);
			w.playSound(null, p.getX(), p.getY(), p.getZ(), snd(head ? "entity.player.attack.crit" : "entity.arrow.hit_player"), SoundCategory.PLAYERS, 0.8f, head ? 1.0f : 1.2f);
			w.spawnParticles(ParticleTypes.CRIT, end.x, end.y, end.z, 10, 0.15, 0.15, 0.15, 0.3);
		} else if (bh.getType() != HitResult.Type.MISS) {
			w.spawnParticles(ParticleTypes.CRIT, end.x, end.y, end.z, 6, 0.1, 0.1, 0.1, 0.2);
			w.playSound(null, end.x, end.y, end.z, snd("block.stone.hit"), SoundCategory.BLOCKS, 1f, 0.8f);
		}

		// smoke tracer
		Vec3d step = end.subtract(eye);
		int n = (int) Math.min(60, step.length() / 2);
		for (int i = 1; i <= n; i++) {
			Vec3d pt = eye.add(step.multiply(i / (double) n));
			w.spawnParticles(ParticleTypes.SMOKE, pt.x, pt.y - 0.1, pt.z, 1, 0, 0, 0, 0);
		}
	}

	private static void reload(ServerPlayerEntity p) {
		ItemStack s = p.getMainHandStack();
		if (!s.isOf(BARRETT) || s.getDamage() == 0) return;
		if (p.getItemCooldownManager().isCoolingDown(s)) return;
		ServerWorld w = (ServerWorld) p.getEntityWorld();
		s.setDamage(0);
		p.getItemCooldownManager().set(s, RELOAD_CD);
		w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("block.iron_trapdoor.open"), SoundCategory.PLAYERS, 1f, 1.3f);
		w.playSound(null, p.getX(), p.getY(), p.getZ(), snd("item.crossbow.loading_end"), SoundCategory.PLAYERS, 1f, 0.8f);
		p.sendMessage(Text.literal("Reloaded " + MAG + "/" + MAG), true);
	}
}
