package com.barrett.mixin;

import com.barrett.GunAnim;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Scope zoom while aiming. Lives in an optional mixin config so a signature change can't crash the game. */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void barrett$zoom(Camera camera, float tickProgress, boolean changingFov, CallbackInfoReturnable<Float> cir) {
		float a = GunAnim.adsAmount();
		if (a > 0.001f) cir.setReturnValue(cir.getReturnValue() * (1f - 0.65f * a));
	}
}
