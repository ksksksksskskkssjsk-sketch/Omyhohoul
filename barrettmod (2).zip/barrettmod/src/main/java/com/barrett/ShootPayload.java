package com.barrett;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** ads = player was aiming down sights (tight spread). */
public record ShootPayload(boolean ads) implements CustomPayload {
	public static final Id<ShootPayload> ID = new Id<>(Identifier.of(BarrettMod.ID, "shoot"));
	public static final PacketCodec<ByteBuf, ShootPayload> CODEC =
			PacketCodecs.BOOLEAN.xmap(ShootPayload::new, ShootPayload::ads);
	@Override public Id<? extends CustomPayload> getId() { return ID; }
}
