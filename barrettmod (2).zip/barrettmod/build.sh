#!/usr/bin/env bash
# Needs Java 21 and Gradle 9.2+ installed. Jar ends up in build/libs/
set -e
if [ -x ./gradlew ]; then ./gradlew build; else gradle build; fi
echo "Done: $(ls build/libs/*.jar | grep -v sources)"
