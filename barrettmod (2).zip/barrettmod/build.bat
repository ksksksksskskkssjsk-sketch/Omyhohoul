@echo off
rem Needs Java 21 and Gradle 9.2+ installed. Jar ends up in build\libs\
if exist gradlew.bat (call gradlew.bat build) else (gradle build)
echo Done. Check build\libs\
pause
